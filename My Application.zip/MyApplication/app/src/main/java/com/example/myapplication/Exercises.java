package com.example.myapplication;
import java.io.LineNumberReader;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.LinkedList;

public class Exercises {
    private static final String[][] ChestEx  = {{"Отжимания"},{"Отжимания","Брусья"},{"Отжимания hard"},{"Отжимания hard","Брусья-hard"}};
    private static final String[][] EnduranceEx  = {{"Бег"},{"Бег","Бёрпи"},{"Бег hard"},{"Бег hard","Бёрпи hard"}};
    private static final String[][] AbsEx  = {{"Пресс"},{"Пресс","Скручивания"},{"Пресс hard"},{"Пресс hard","Скручивания hard"}};
    private static final String[][] CoreEx  = {{"Лодочка"},{"Лодочка","Планка"},{"Лодочка hard"},{"Лодочка hard","Планка hard"}};
    private static final String[][] LegsEx  = {{"Приседания"},{"Приседания","Бег"},{"Приседания hard"},{"Приседания hard","Бег hard"}};


  /*  public static LinkedHashSet<String> getChestExercises()
    {
        return (LinkedHashSet<String>) new LinkedHashSet<>(Arrays.asList(ChestEx));
    }
    public static LinkedHashSet<String> getEnduranceExercises()
    {
        return (LinkedHashSet<String>) new LinkedHashSet<>(Arrays.asList(EnduranceEx));
    }
    public static LinkedHashSet<String> getAbsExercises()
    {
        return (LinkedHashSet<String>) new LinkedHashSet<>(Arrays.asList(AbsEx));
    }
    public static LinkedHashSet<String> getCoreExercises()
    {
        return (LinkedHashSet<String>) new LinkedHashSet<>(Arrays.asList(CoreEx));
    }
    public static LinkedHashSet<String> getLegsExercises()
    {
        return (LinkedHashSet<String>) new LinkedHashSet<>(Arrays.asList(LegsEx));
    }*/



    public static LinkedHashSet<String> getChestExercisesByLevel(int level)
    {
        LinkedHashSet<String> Res= new LinkedHashSet<>();
        LinkedList<String> myList = (LinkedList<String>) Arrays.asList(ChestEx[level-1]);
        Res= (LinkedHashSet<String>) new LinkedHashSet<String>(myList);
        return Res;
    }
    public static LinkedHashSet<String> getEnduranceExercisesByLevel(int level)
    {
        LinkedHashSet<String> Res= new LinkedHashSet<>();
        Res= (LinkedHashSet<String>) new LinkedHashSet<String>(Arrays.asList(EnduranceEx[level-1]));
        return Res;
    }
    public static LinkedHashSet<String> getAbsExercisesByLevel(int level)
    {
        LinkedHashSet<String> Res= new LinkedHashSet<>();
        Res= (LinkedHashSet<String>) new LinkedHashSet<String>(Arrays.asList(AbsEx[level-1]));
        return Res;
    }
    public static LinkedHashSet<String> getCoreExercisesByLevel(int level)
    {
        LinkedHashSet<String> Res= new LinkedHashSet<>();
        Res= (LinkedHashSet<String>) new LinkedHashSet<String>(Arrays.asList(CoreEx[level-1]));
        return Res;
    }
    public static LinkedHashSet<String> getLegsExercisesByLevel(int level)
    {
        LinkedHashSet<String> Res= new LinkedHashSet<>();
        Res= (LinkedHashSet<String>) new LinkedHashSet<String>(Arrays.asList(LegsEx[level-1]));
        return Res;
    }


}
