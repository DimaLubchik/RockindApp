package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.content.DialogInterface;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private long backPressedTime;
    private Toast backToast;
    private TextView myText;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //-верхняя панель
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //-конец

    }
    public void onClickTestButton(View view)
    {

        AlertDialog.Builder a_builder =new AlertDialog.Builder(MainActivity.this);
        a_builder.setMessage("Перед прохождением теста, внимательно прочитайте инструкцию.")
                .setCancelable(false)
                .setPositiveButton("Продолжить", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        Intent goal = new Intent(getApplicationContext(), TutorialActivity.class);
                        startActivity(goal);
                    }
                });
        AlertDialog TestButton = a_builder.create();
        TestButton.setTitle("Ознакомьтесь перед переходом");
        TestButton.show();
    }
    public void onClickProgramsButton(View view)
    {
        Intent goal= new Intent (this,ProgramsActivity.class);

        startActivity(goal);
    }

    @Override
    public void onBackPressed() {

        if (backPressedTime + 2000 > System.currentTimeMillis())
        {
            backToast.cancel();
            super.onBackPressed();
            return;
        }
        else{
            backToast=Toast.makeText(getBaseContext(),"Нажмите ещё раз, чтобы выйти", Toast.LENGTH_SHORT);
            backToast.show();
        }
            backPressedTime = System.currentTimeMillis();
    }
}