package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.LinkedList;
import java.util.List;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Toast;

public class BasicExercises extends AppCompatActivity {
    float x1, x2, y1, y2;

    public boolean onTouchEvent(MotionEvent touchevent){
        switch (touchevent.getAction()){
            case MotionEvent.ACTION_DOWN:
                x1=touchevent.getX();
                y1=touchevent.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2=touchevent.getX();
                y2=touchevent.getY();
                if(x1 < x2){
                    Intent i = new Intent(BasicExercises.this, ProgramsActivity.class);
                    startActivity(i);
                }
        }

        return false;
    }
    // свайп конец

    ListView ListView;
    String mTitle[] = {"Press","Arms","Legs","Neck","Back"};//Пресс, Руки,Ноги,Шея,Спина
    String mDescription[] = {"Press Description", "Arms Description", "Legs Description", "Neck Description", "Back Description"};
    int images[]= {R.drawable.press, R.drawable.arms, R.drawable.legs, R.drawable.neck, R.drawable.back};
    //установка изображений в массив



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_exercises);

        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        ListView=findViewById(R.id.listView);

        MyAdapter adapter = new MyAdapter(this,mTitle, mDescription,images );
        ListView.setAdapter(adapter);

        //setClick on list view
        ListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0){
                    Toast.makeText(BasicExercises.this, "Press Description", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(view.getContext(),Press.class);
                    startActivity(intent);
                }
                if (position == 1){
                    Toast.makeText(BasicExercises.this, "Arms Description", Toast.LENGTH_SHORT).show();
                }
                if (position == 2){
                    Toast.makeText(BasicExercises.this, "Legs Description", Toast.LENGTH_SHORT).show();
                }
                if (position == 3){
                    Toast.makeText(BasicExercises.this, "Neck Description", Toast.LENGTH_SHORT).show();
                }
                if (position == 4){
                    Toast.makeText(BasicExercises.this, "Back Description", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }

    class MyAdapter extends ArrayAdapter<String>{

        Context context;
        String rTitle[];
        String rDescription[];
        int rImgs[];

        MyAdapter (Context c, String title[], String description[], int imgs[]) {
            super(c,R.layout.row, R.id.textView1, title);
            this.context = c;
            this. rTitle = title;
            this. rDescription= description;
            this.rImgs=imgs;


        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater= (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View row = layoutInflater.inflate(R.layout.row, parent, false);

            //присваивание фотографии в row массивом
            ImageView images = row.findViewById(R.id.image);
            TextView myTitle = row.findViewById(R.id.textView1);
            TextView myDescription = row.findViewById(R.id.textView2);

            //позиция по номеру массива
            images.setImageResource(rImgs[position]);
            myTitle.setText(rTitle[position]);
            myDescription.setText(rDescription[position]);



            return row;
        }
    }
}