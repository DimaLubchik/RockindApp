package com.example.myapplication;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.example.myapplication.Exercises;

public class ProgramsActivity extends AppCompatActivity {
    //свайп начало
    float x1, x2, y1, y2;

    public boolean onTouchEvent(MotionEvent touchevent){
        switch (touchevent.getAction()){
            case MotionEvent.ACTION_DOWN:
                x1=touchevent.getX();
                y1=touchevent.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2=touchevent.getX();
                y2=touchevent.getY();
                if(x1 > x2){
                    Intent i = new Intent(ProgramsActivity.this, BasicExercises.class);
                    startActivity(i);
                }
        }

        return false;
    }
    // свайп конеw

   String temp;
   String[] answersForPrograms;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_programs);

        SharedPreferences save= getSharedPreferences("SAVE",0);
        SharedPreferences.Editor editor = save.edit();
        temp=  save.getString("results","");
        String s=temp.toString();
        s=s.substring(1,s.length()-1);
        answersForPrograms=s.split(",");
         // обработка ответов, и передача в програмс активити -конец


        List <Integer> Levels= new LinkedList<>();

        List<String> MuscleGroups= new LinkedList<>();
        MuscleGroups.add("Chest");
        MuscleGroups.add("Endurance");
        MuscleGroups.add("Abs");
        MuscleGroups.add("Core");
        MuscleGroups.add("Legs");



        for(int i=0;i<answersForPrograms.length;i++) {
            Integer el = Integer.parseInt(answersForPrograms[i].substring(answersForPrograms[i].length() - 1));//Взятие последнего элемента первого ответа и преобразование в интеджер
            Levels.add(el);
            System.out.println(el);

        }
        List<Integer> numOfEx=new LinkedList<>();//Количество упражнений на каждую группу
        for(int i=0;i<Levels.size();i++)
        {
            String currentMuscleGroup=MuscleGroups.get(i);

            int currentLevel=Levels.get(i);
            if(currentMuscleGroup=="Chest")
            {

                LinkedHashSet<String> Ex= new LinkedHashSet<>();
                Ex=Exercises.getChestExercisesByLevel(currentLevel);
                editor.putStringSet(currentMuscleGroup,Ex);
            }
            if(currentMuscleGroup=="Endurance")
            {

                LinkedHashSet<String> Ex= new LinkedHashSet<>();
                Ex=Exercises.getEnduranceExercisesByLevel(currentLevel);
                editor.putStringSet(currentMuscleGroup,Ex);
            }
            if(currentMuscleGroup=="Abs")
            {

                LinkedHashSet<String> Ex= new LinkedHashSet<>();
                Ex=Exercises.getAbsExercisesByLevel(currentLevel);
                editor.putStringSet(currentMuscleGroup,Ex);
            }
            if(currentMuscleGroup=="Core")
            {

                LinkedHashSet<String> Ex= new LinkedHashSet<>();
                Ex=Exercises.getCoreExercisesByLevel(currentLevel);
                editor.putStringSet(currentMuscleGroup,Ex);
            }
            if(currentMuscleGroup=="Legs")
            {

                LinkedHashSet<String> Ex= new LinkedHashSet<>();
                Ex=Exercises.getLegsExercisesByLevel(currentLevel);
                editor.putStringSet(currentMuscleGroup,Ex);
            }
            editor.commit();
        }



    }
 public void onClickInfoButton (View view) {
     AlertDialog.Builder a_builder =new AlertDialog.Builder(ProgramsActivity.this);
     a_builder.setMessage("!!!")
             .setCancelable(false)
             .setPositiveButton("Закрыть", new DialogInterface.OnClickListener() {
                 @Override
                 public void onClick(DialogInterface dialog, int which) {
                     dialog.cancel();
                 }
             });
     AlertDialog TestButton = a_builder.create();
     TestButton.setTitle("Ознакомьтесь перед переходом");
     TestButton.show();
 }
public void onClickFirstWeekButton (View view) {
    Intent goal= new Intent (this,FirstWeekActivity.class);
    startActivity(goal);
}
public void onClickSecondWeekButton(View view){
    Intent goal= new Intent (this,SecondWeekActivity.class);
    startActivity(goal);
}

}
